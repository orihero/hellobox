import styled from "styled-components";

export const BUTTON = styled.button`
  width: 100%;
  height: auto;
`;
